﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eindopdracht_DD2.Classes
{
    internal class MuseumUitje : Uitje
    {
        private decimal toegangsprijs { get; set; }
        public decimal Toegangsprijs { get; set; }
    }
}
