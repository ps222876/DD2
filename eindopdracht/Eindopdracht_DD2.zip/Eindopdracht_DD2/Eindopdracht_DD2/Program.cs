﻿// See https://aka.ms/new-console-template for more information
using Eindopdracht_DD2.Classes;
using System.Collections.Generic;


Binnenwedstrijd binnenwedstrijd1 = new Binnenwedstrijd();
binnenwedstrijd1.Naam = "BinnenWedstrijd1";
binnenwedstrijd1.StartDatum = DateTime.Now;
binnenwedstrijd1.WedstrijdDuur = new TimeSpan(3, 0, 0);
binnenwedstrijd1.Doorstroom = false;



Buitenwedstrijd buitenwedstrijd1 = new Buitenwedstrijd();
buitenwedstrijd1.Naam = "BuitWedstrijd2";
buitenwedstrijd1.StartDatum = DateTime.Now;
buitenwedstrijd1.WedstrijdDuur = new TimeSpan(3, 0, 0);
buitenwedstrijd1.Doorstroom = true;



MuseumUitje museum1 = new MuseumUitje();
museum1.Naam = "Museum1";
museum1.StartDatum = DateTime.Now;
museum1.BinnenEvent = true;
museum1.Doorstroom = true;
museum1.Toegangsprijs = 6;



BioscoopUitje film1 = new BioscoopUitje();
film1.Naam = "Fast and furious";
film1.StartDatum = DateTime.Now;
film1.Doorstroom = true;
film1.BinnenEvent = true;
film1.AanvangsTijdstip = new DateTime(2022, 10, 10, 16, 30, 05);
film1.Duur = new TimeSpan(3, 0, 0);
film1.Zaal = "zaal 1";
film1.Stoel = "24";









//List

List<Binnenwedstrijd> binnenwedstrijden = new List<Binnenwedstrijd>();
binnenwedstrijden.Add(binnenwedstrijd1);


List<Buitenwedstrijd> buitenwedstrijden = new List<Buitenwedstrijd>();
buitenwedstrijden.Add(buitenwedstrijd1);


List<MuseumUitje> museumUitje = new List<MuseumUitje>();
museumUitje.Add(museum1);

List<BioscoopUitje> bioscoopUitje = new List<BioscoopUitje>();
bioscoopUitje.Add(film1);

List<Uitje> uitjes = new List<Uitje>();
uitjes.Add(new BioscoopUitje());
uitjes.Add(new MuseumUitje());

List<Wedstrijd> wedstrijden = new List<Wedstrijd>();
wedstrijden.Add(new Buitenwedstrijd());
wedstrijden.Add(new Binnenwedstrijd());

List<ICoronaCheckEvenement> coronaCheckEvenements = new List<ICoronaCheckEvenement>();

//toon binnenwedstrijden

Console.WriteLine("Hieronder zie je alle binnenwedstrijden");
foreach (Binnenwedstrijd binnenwedstrijd in binnenwedstrijden)
{
    if (binnenwedstrijd is ICoronaCheckEvenement)
    {
        Console.WriteLine("");
        Console.WriteLine("Naam evenement: " + binnenwedstrijd.Naam);
        Console.WriteLine("Startdatum evenement: " + binnenwedstrijd.StartDatum);
        Console.WriteLine("Duur evenement: " + binnenwedstrijd.WedstrijdDuur);
        Console.WriteLine("Is er een doorstroom bij het evenement: " + binnenwedstrijd.Doorstroom);
/*        Console.WriteLine("");
*/        Console.WriteLine("Heeft u een vasteplaats: " + ((ICoronaCheckEvenement)binnenwedstrijd).VastePlaats());
        Console.WriteLine("Is het evenement buiten: " + ((ICoronaCheckEvenement)binnenwedstrijd).Buiten());
        Console.WriteLine("Is er een coronaceck verplicht: " + ((ICoronaCheckEvenement)binnenwedstrijd).CoronaCheckRequired());
    }
}
Console.WriteLine("----------------------------------------");





//toon buitenwedstrijden
Console.WriteLine("Hieronder zie je alle buitenwedstrijden");
foreach (Buitenwedstrijd buitenwedstrijd in buitenwedstrijden)
{
    if (buitenwedstrijd is ICoronaCheckEvenement)
    {
        Console.WriteLine("");
        Console.WriteLine("Naam evenement: " + buitenwedstrijd.Naam);
        Console.WriteLine("Startdatum evenement: " + buitenwedstrijd.StartDatum);
        Console.WriteLine("Duur evenement: " + buitenwedstrijd.WedstrijdDuur);
        Console.WriteLine("Is er een doorstroom bij het evenement: " + buitenwedstrijd.Doorstroom);
/*        Console.WriteLine("");
*/        Console.WriteLine("Heeft u een vasteplaats: " + ((ICoronaCheckEvenement)buitenwedstrijd).VastePlaats());
        Console.WriteLine("Is het evenement buiten: " + ((ICoronaCheckEvenement)buitenwedstrijd).Buiten());
        Console.WriteLine("Is er een coronaceck verplicht: " + ((ICoronaCheckEvenement)buitenwedstrijd).CoronaCheckRequired());
    }
}
Console.WriteLine("----------------------------------------");


//toon museumuitjes
Console.WriteLine("Hieronder zie je alle museumuitjes");

foreach (MuseumUitje mUitje1 in museumUitje)
{
    if (museum1 is ICoronaCheckEvenement)
    {
        Console.WriteLine("");
        Console.WriteLine("Naam evenement: " + mUitje1.Naam);
        Console.WriteLine("Startdatum evenement: " + mUitje1.StartDatum);
        Console.WriteLine("Het museum Evenement: " + mUitje1.BinnenEvent);
        Console.WriteLine("Is er een doorstroom bij het evenement: " + mUitje1.Doorstroom);
        Console.WriteLine("De toegangsprijs van het evenement: " + mUitje1.Toegangsprijs);
        Console.WriteLine("");
        Console.WriteLine("Heeft u een vasteplaats: " + ((ICoronaCheckEvenement)mUitje1).VastePlaats());
        Console.WriteLine("Is het evenement buiten: " + ((ICoronaCheckEvenement)mUitje1).Buiten());
        Console.WriteLine("Is er een coronaceck verplicht: " + ((ICoronaCheckEvenement)mUitje1).CoronaCheckRequired());
    }
}

Console.WriteLine("----------------------------------------");



//toon bioscoopuitjes
Console.WriteLine("Hieronder zie je alle bioscoopuitjes");

foreach (BioscoopUitje bUitje1 in bioscoopUitje)
{
    if (museum1 is ICoronaCheckEvenement)
    {
        Console.WriteLine("");
        Console.WriteLine("Naam evenement: " + bUitje1.Naam);
        Console.WriteLine("Startdatum evenement: " + bUitje1.StartDatum);
        Console.WriteLine("Het bioscoop Evenement: " + bUitje1.BinnenEvent);
        Console.WriteLine("De zaal nummer: " + bUitje1.Zaal);
        Console.WriteLine("Duur evenement: " + bUitje1.Duur);
        Console.WriteLine("De stoel nummer: " + bUitje1.Stoel);
        Console.WriteLine("De aanvangstijdstip: " + bUitje1.AanvangsTijdstip);
        Console.WriteLine("Is er een doorstroom bij het evenement: " + bUitje1.Doorstroom);
        Console.WriteLine("");
        Console.WriteLine("Heeft u een vasteplaats: " + ((ICoronaCheckEvenement)bUitje1).VastePlaats());
        Console.WriteLine("Is het evenement buiten: " + ((ICoronaCheckEvenement)bUitje1).Buiten());
        Console.WriteLine("Is er een coronaceck verplicht: " + ((ICoronaCheckEvenement)bUitje1).CoronaCheckRequired());
    }
}

Console.WriteLine("----------------------------------------");